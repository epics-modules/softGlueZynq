/* DMA Proxy Test Application
 *
 * This application is intended to be used with the DMA Proxy device driver. It provides
 * an example application showing how to use the device driver to do user space DMA
 * operations.
 *
 * It has been tested with an AXI DMA system with transmit looped back to receive.
 * The device driver implements a blocking ioctl() function such that a thread is
 * needed for the 2nd channel. Since the AXI DMA transmit is a stream without any
 * buffering it is throttled until the receive channel is running.
 */

#include <stdio.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <pthread.h>

/* for my modifications tmm */
#include <stdlib.h>
#include <time.h>

#include "dma_proxy.h"

static struct dma_proxy_channel_interface *tx_proxy_interface_p;
static int tx_proxy_fd;
static int dma_length = TEST_SIZE;

/* The following function is the transmit thread to allow the transmit and the
 * receive channels to be operating simultaneously. The ioctl calls are blocking
 * such that a thread is needed.
 */
void *tx_thread()
{
	int dummy, i;

	/* Set up the length for the DMA transfer and initialize the transmit
 	 * buffer to a known pattern.
 	 */
	tx_proxy_interface_p->length = dma_length;

    	for (i = 0; i < dma_length; i++)
       		tx_proxy_interface_p->buffer[i] = i;

	/* Perform the DMA transfer and the check the status after it completes
 	 * as the call blocks til the transfer is done.
 	 */
	ioctl(tx_proxy_fd, 0, &dummy);

	if (tx_proxy_interface_p->status != PROXY_NO_ERROR)
		printf("Proxy tx transfer error\n");
}

/* The following function uses the dma proxy device driver to perform DMA transfers
 * from user space. This app and the driver are tested with a system containing an
 * AXI DMA without scatter gather and with transmit looped back to receive.
 */
 #define DMA_TX 1
 #define DMA_RX 2
 
/* command line: /bin/dma_proxy_test numBytes dir timeout_ms verbose
 * To read 65536 bytes with 10 ms timeout, and write the values:
 * e.g. /bin/dma_proxy_test 65536 2 10 1
 */
int main(int argc, char *argv[])
{
	struct dma_proxy_channel_interface *rx_proxy_interface_p;
	int rx_proxy_fd, i;
	int dummy = 0;
	pthread_t tid;
	struct timespec tStart, tEnd;
	double deltaT;
	int dirMap = DMA_TX | DMA_RX;
	int timeout_msecs = 3000;
	int verbose = 0;

	if (argc>1) {
		dma_length = atof(argv[1]);
	} else {
		dma_length = TEST_SIZE;
	}
	if (dma_length > ALLOC_SIZE) {
		dma_length = ALLOC_SIZE;
		printf("DMA proxy test: restricting dma_length to allocated length of %d bytes\n", dma_length);
	}

	if (argc>2) {
		dirMap = atol(argv[2]);
	}

	if (argc>3) {
		timeout_msecs = atol(argv[3]);
	}

	if (argc>4) {
		verbose = atol(argv[4]);
	}

	printf("DMA proxy test: dirMap = %d, TX = %d, RX = %d, timeout_msecs = %d\n",
		dirMap, (dirMap&DMA_TX)!=0, (dirMap&DMA_RX)!=0, timeout_msecs);

	/* Step 1, open the DMA proxy device for the transmit and receive channels with
 	 * read/write permissions
 	 */

	if (dirMap & DMA_TX) {
		tx_proxy_fd = open("/dev/dma_proxy_tx", O_RDWR);

		if (tx_proxy_fd < 1) {
			printf("Unable to open DMA proxy device file for TX\n");
			return -1;
		}
	}

	if (dirMap & DMA_RX) {
		rx_proxy_fd = open("/dev/dma_proxy_rx", O_RDWR);
		if (rx_proxy_fd < 1) {
			printf("Unable to open DMA proxy device file for RX\n");
			return -1;
		}
	}

	/* Step 2, map the transmit and receive channels memory into user space so it's accessible */
	if (dirMap & DMA_TX) {
		tx_proxy_interface_p = (struct dma_proxy_channel_interface *)mmap(NULL, sizeof(struct dma_proxy_channel_interface),
									PROT_READ | PROT_WRITE, MAP_SHARED, tx_proxy_fd, 0);
    	if (tx_proxy_interface_p == MAP_FAILED) {
        	printf("Failed to mmap for TX\n");
        	return -1;
    	}
		tx_proxy_interface_p->length = dma_length;
		tx_proxy_interface_p->timeout_msecs = timeout_msecs;
	}

	if (dirMap & DMA_RX) {
		rx_proxy_interface_p = (struct dma_proxy_channel_interface *)mmap(NULL, sizeof(struct dma_proxy_channel_interface),
									PROT_READ | PROT_WRITE, MAP_SHARED, rx_proxy_fd, 0);

    	if (rx_proxy_interface_p == MAP_FAILED) {
        	printf("Failed to mmap for RX\n");
        	return -1;
    	}
		rx_proxy_interface_p->length = dma_length;
		rx_proxy_interface_p->timeout_msecs = timeout_msecs;
	}

	/* Create the thread for the transmit processing and then wait a second so the printf output is not
 	 * intermingled with the receive processing
	 */
	if (dirMap & DMA_TX) {
		pthread_create(&tid, NULL, tx_thread, NULL);
		sleep(1);
	}

	clock_gettime(CLOCK_REALTIME, &tStart);
	/* Initialize the receive buffer so that it can be verified after the transfer is done
	 * and setup the size of the transfer for the receive channel
 	 */
	if (dirMap & DMA_RX) {
		for (i = 0; i < dma_length; i++) {
			rx_proxy_interface_p->buffer[i] = 0;
		}

		/* Step 3, Perform the DMA transfer and after it finishes check the status */
		ioctl(rx_proxy_fd, 0, &dummy);

		if (rx_proxy_interface_p->status != PROXY_NO_ERROR) {
			printf("Proxy rx transfer error\n");
		}
	}

	clock_gettime(CLOCK_REALTIME, &tEnd);

	if ((dirMap & DMA_TX) && (dirMap&DMA_RX)) {
		/* Verify the data recieved matchs what was sent (tx is looped back to tx) */
		for (i = 0; i < dma_length; i++) {
        	if (tx_proxy_interface_p->buffer[i] != rx_proxy_interface_p->buffer[i]) {
            	printf("dma_proxy_test:buffer not equal, index = %d\n", i);
			} else {
				if (i < 10)
            		printf("dma_proxy_test:tx buffer[%d] = rx buffer[%d] = %d\n", i, i, tx_proxy_interface_p->buffer[i]);
			}
    	}
	}

	if (verbose) {
		for (i = 0; i < dma_length; i++) {
            printf("dma_proxy_test:rx buffer[%d] = %d\n", i, rx_proxy_interface_p->buffer[i]);
    	}
	}

	/* Unmap the proxy channel interface memory and close the device files before leaving
	 */
	if (dirMap & DMA_TX) {
		munmap(tx_proxy_interface_p, sizeof(struct dma_proxy_channel_interface));
		close(tx_proxy_fd);
	}
	if (dirMap & DMA_RX) {
		munmap(rx_proxy_interface_p, sizeof(struct dma_proxy_channel_interface));
		close(rx_proxy_fd);
	}

	deltaT = (tEnd.tv_sec + tEnd.tv_nsec*1.e-9) - (tStart.tv_sec + tStart.tv_nsec*1.e-9);
	printf("dma_proxy_test: %d bytes in %f seconds.\n",	dma_length, deltaT);
	return 0;
}
