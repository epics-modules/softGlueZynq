#!/bin/sh

if [ -e /media/card/userConfig ]; then
	echo "found userConfig file"
	source /media/card/userConfig

	echo "mount SHARE and IOC file systems"
	mkdir /mnt${SHAREMOUNT}
	mkdir /mnt${IOCMOUNT}
	mkdir -p `dirname $SHARELOCAL`
	mkdir -p `dirname $IOCLOCAL`
	ln -s /mnt${SHAREMOUNT} $SHARELOCAL
	ln -s /mnt${IOCMOUNT} $IOCLOCAL
	ln -s /mnt${SHAREMOUNT} ${SHAREMOUNT}
	mount -o port=2049,nolock -t nfs ${SHARESERVER}:${SHAREMOUNT} /mnt${SHAREMOUNT}
	mount -o port=2049,nolock -t nfs ${IOCSERVER}:${IOCMOUNT} /mnt${IOCMOUNT}
fi
